
$(document).ready(function(){ 

    chrome.tabs.query({
        active: true,
        lastFocusedWindow: true
    }, function (tabs) {
        var url = tabs[0].url;
        on_load_features(url);
        get_copy_clipboard();
        get_newtab();
    });

    $("#selected_area").change(function(){
        if($(this).val() != 0) {
            handle_url();
        }
    });

   $("#btn_databases").click(function() {
       switch_databases();
   });

   $("#btn_mbox").click(function(){
       paramaters_handler('?mboxDisable=1');
   });

   $("#btn_errorpage").click(function(){
        paramaters_handler("?throwException=true");
   });

   $("#clipboard").click(function(){
        set_copy_clipboard($("#clipboard").is(":checked"));
   });

   $("#new_tab").click(function(){
        set_newtab($("#new_tab").is(":checked"));
    });

    $("#show_config").click(function(){
        document.getElementById('config_section').style.display = 'block';
        $("#first_db").val(get_first_database());
        $("#second_db").val(get_second_database());
    });

    $("#save_changes").click(function(){
        set_first_database($("#first_db").val());
        set_second_database($("#second_db").val());
        document.getElementById('config_section').style.display = 'none';
    });


});

function handle_url(){
    chrome.tabs.query({
        active: true,
        lastFocusedWindow: true
    }, function (tabs) {
        var url = tabs[0].url;
        url = clean_url(url);
        update_url(url + get_ipmask_parameter() + $("#selected_area").val());
    });
}

function get_ipmask_parameter(){
    return "?ipmask=";
}

function clean_url(old_url){
    if (old_url.indexOf("?ipmask=") > -1) {
        ip_mask_index = old_url.indexOf("?ipmask=");
        var original_url = old_url.slice(0, ip_mask_index);
        return original_url;
    } else {
        return old_url;
    }
    
}

function paramaters_handler(parameter){
    var my_paramater = parameter;
    chrome.tabs.query({
        active: true,
        lastFocusedWindow: true
    }, function (tabs) {
        var url = tabs[0].url;
        url = clean_url(url);
        if (url.indexOf(my_paramater) > -1 ) {
            url = url.replace(my_paramater, "");
        } else {
            url += my_paramater;
        }
        update_url(url);
    });
   
}

function switch_databases(){
    
    var new_url;
    chrome.tabs.query({
        active: true,
        lastFocusedWindow: true
    }, function (tabs) {
        var url = tabs[0].url;
        if (url.indexOf(get_second_database()) > -1) {
            new_url = url.replace(get_second_database(), get_first_database());
        }

        if (url.indexOf(get_first_database()) > -1) {
            new_url = url.replace(get_first_database(), get_second_database());
        }
        update_url(new_url);
    });
}

function copy_to_clipboard(my_url){
    if ($("#clipboard").is(":checked")) {
        var $temp = $("<input>");
        $("body").append($temp);
        $temp.val(my_url).select();
        document.execCommand("copy");
        $temp.remove();
    }

}

function update_url(new_url){
    if (!$("#new_tab").is(":checked")) {
        chrome.tabs.update({url: new_url}); 
    } else {
        chrome.tabs.create({url: new_url});
    }
    copy_to_clipboard(new_url);
    on_load_features(new_url);
}

function on_load_features(url){
    if (url.indexOf("?mboxDisable=1") > -1) {
        $("#btn_mbox").css("background-color", "#81c23c");
    } else {
        $("#btn_mbox").css("background-color", "#f99d1c");
    }

    if (url.indexOf("?throwException=true") > -1) {
        $("#btn_errorpage").css("background-color", "#81c23c");
    } else {
        $("#btn_errorpage").css("background-color", "#f99d1c");
    }

    if (url.indexOf(get_first_database()) > -1) {
        $("#first-db-img").attr("src","img/database-dark.png");
        $("#second-db-img").attr("src","img/database.png");
    } else {
        $("#first-db-img").attr("src","img/database.png");
        $("#second-db-img").attr("src","img/database-dark.png");
    }

    if (url.indexOf("?ipmask=")) {
        var current_ip = url.indexOf('?ipmask=');
        if (current_ip > -1) {
            $("#selected_area").val(url.slice(current_ip + 8, url.length));
            $("#selected_area").css("border-color", "green");
            $("#selected_area").css("border-width", "3px");
        }
    }

}




