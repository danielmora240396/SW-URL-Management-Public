

function get_database(xml, database) {
    var x = xml.getElementsByTagName('database')[database].childNodes[0].nodeValue;
    document.getElementById("demo").innerHTML = x; 
}

 function get_xml(file, data){
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var my_file = this.responseXML;
            if (data == 0) {
                get_database(my_file, data);
            }
            if (data == 1) {
                get_database(my_file, data);
            }

        }
    };
    xhttp.open("GET", file, true);
    xhttp.send();
}


function get_config(file){
   var my_file = new XMLHttpRequest();
   my_file.overrideMimeType("application/json");
   my_file.open('GET', file, true);
   my_file.onreadystatechange = function() {
    if (my_file.readyState === 4 && my_file.status == "200") {
        callback(my_file.responseText);
    }
}
my_file.send(null);

}


function set_config(flag){
    /*var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var my_file = this.responseXML;
            alert(flag);
            if (flag) {
                my_file.getElementsByTagName('option')[0].childNodes[0].nodeValue = "true";
            } else{
                my_file.getElementsByTagName('option')[0].childNodes[0].nodeValue = "false";
            }
            
        }
    };
    xhttp.open("get", 'config_files/checkbox_config.xml', true);
    xhttp.send();*/
    var doc = loadXMLDoc("")
}

