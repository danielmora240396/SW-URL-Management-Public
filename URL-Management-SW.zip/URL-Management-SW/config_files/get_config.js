function get_copy_clipboard(){
    if (localStorage.clipboard == undefined) {
        localStorage.clipboard = false;
    }

    if (localStorage.clipboard == "false") {
        $("#clipboard").attr('checked', false);
    } else {
        $("#clipboard").attr('checked', true);
    }

    return localStorage.clipboard;
    
}

function get_newtab(){
    if (localStorage.newtab == undefined) {
        localStorage.newtab = false;
    }

    if (localStorage.newtab == "false") {
        $("#new_tab").attr('checked', false);
    } else {
        $("#new_tab").attr('checked', true);
    }

    return localStorage.newtab;
}

function get_first_database(){
    if (localStorage.first_database == undefined) {
        localStorage.setItem("first_database", "author.azure");
    }
    return localStorage.first_database;
}

function get_second_database(){
    if (localStorage.second_database == undefined) {
        localStorage.setItem("second_database", "www");
    }
    return localStorage.second_database;
}