function set_copy_clipboard(flag){
    localStorage.setItem("clipboard", flag);
}

function set_newtab(flag){
    localStorage.setItem("newtab", flag);
}

function set_first_database(database){
    localStorage.setItem("first_database", database);
}

function set_second_database(database){
    localStorage.setItem("second_database", database);
}

